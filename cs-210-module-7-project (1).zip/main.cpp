#include <Python.h>
#include <iostream>
#include <iomanip>
#define NOMINMAX
#include <Windows.h>
#undef NOMINMAX
#include <cmath>
#include <string>
#include <fstream>

using namespace std;

void CallProcedure(string pName)
{
	char *procname = new char[pName.length() + 1];
	std::strcpy(procname, pName.c_str());

	Py_Initialize();
	PyObject* my_module = PyImport_ImportModule("PythonCode");
	PyErr_Print();	
	PyObject* my_function = PyObject_GetAttrString(my_module, procname);
	PyObject* my_result = PyObject_CallObject(my_function, NULL);
	Py_Finalize();

	delete[] procname;
}

int callIntFunc(string proc, string param)
{
	char *procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	char *paramval = new char[param.length() + 1];
	std::strcpy(paramval, param.c_str());


	PyObject *pName, *pModule, *pDict, *pFunc, *pValue = nullptr, *presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(z)", paramval);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;
	delete[] paramval;


	return _PyLong_AsInt(presult);
}

int callIntFunc(string proc, int param)
{
	char *procname = new char[proc.length() + 1];
	std::strcpy(procname, proc.c_str());

	PyObject *pName, *pModule, *pDict, *pFunc, *pValue = nullptr, *presult = nullptr;
	// Initialize the Python Interpreter
	Py_Initialize();
	// Build the name object
	pName = PyUnicode_FromString((char*)"PythonCode");
	// Load the module object
	pModule = PyImport_Import(pName);
	// pDict is a borrowed reference 
	pDict = PyModule_GetDict(pModule);
	// pFunc is also a borrowed reference 
	pFunc = PyDict_GetItemString(pDict, procname);
	if (PyCallable_Check(pFunc))
	{
		pValue = Py_BuildValue("(i)", param);
		PyErr_Print();
		presult = PyObject_CallObject(pFunc, pValue);
		PyErr_Print();
	}
	else
	{
		PyErr_Print();
	}
	//printf("Result is %d\n", _PyLong_AsInt(presult));
	Py_DECREF(pValue);
	// Clean up
	Py_DECREF(pModule);
	Py_DECREF(pName);
	// Finish the Python Interpreter
	Py_Finalize();

	// clean 
	delete[] procname;

	return _PyLong_AsInt(presult);
}

void drawMenu() {

    // Tracks how many menu loops //
    int menuLoops = 0;
    
    // Tracks how many times a specific word was found throughout //
    int wordCount = 0;
    
    // Variable for count of items //
    int itemCount = 0;
    
    // Receive user input //
    string searchItem;
    
    // Variable for item name //
    string itemName;
    
    // Sets font color as blue for the asterisks in the histogram //
    string blueColor = "\033[32;1m";
    
    // Sets font color to default //
    string defaultColor = "\033[0m";
    
    // Opens ifstream //
    ifstream fileInput;

    while (menuLoops != 4) {

        // Receive user input //
        std::cout  << "[1] Calculate how many times each item appears" << std::endl;
        std::cout  << "[2] Calculate the frequency of a specific item" << std::endl;
        std::cout  << "[3] Create a histogram based on the frequency of each item" << std::endl;
        std::cout  << "[4] Quit" << std::endl;
        std::cin >> menuLoops;

        // Check user input. If invalid, prompt the user for the correct input //
        while (std::cin.fail()) {
            std::cin.clear();
            std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
            std::cout << "Selection invalid. Try again: ";
            std::cin >> menuLoops;
            }

            // Switch statement to gather user input //
            switch (menuLoops) {

                // Calculate how many times each item in list appears //
                case 1:
                
                    // Clear screen for better looking output //
                    system("CLS");
                    
                    // Call the function CountAll //
                    CallProcedure("CountAll");
                    
                    // Empty line //
                    std::cout << std::endl;
                    break;

                // Calculate quanitites of specific items in list //
                case 2:
                    // Clear screen for better looking output //
                    system("CLS");
                    std::cout << "What item are you looking for?" << std::endl;
                    
                    // Receive user input //
                    std::cin >> searchItem;                                                           

                    // Returns wordCount value as integer //
                    wordCount = callIntFunc("CountItems", searchItem);                  

                    // Print statement for wordCount //
                    std::cout << std::endl << searchItem << " : " << wordCount << std::endl << std::endl;

                    break;

                // Print histrogram based on quantity of items appearing //
                case 3:
                
                    // Clear the screen to make the output look better //
                    system("CLS");
                    
                    // Calls python function //
                    CallProcedure("CollectData");
                    
                    // Open file //
                    fileInput.open("frequency.dat");
                    
                    // Takes first item in list //
                    fileInput >> itemName;
                    
                    // Takes first quantity in list //
                    fileInput >> itemCount;

                    // Prompts a histogram for every line in the file, followed by a break statement //
                    while (!fileInput.fail()) {
                        // Set font color to default, or white //
                        std::cout << defaultColor;

                        // Create histogram settings //
                        std::cout << std::setw(14) << std::left << itemName << std::setw(6);

                        // Set color of the histogram //
                        std::cout << blueColor;

                        // Print itemCount //
                        for (int i = 0; i < itemCount; i++) {
                            
                            // Print asterisks to make output look better //
                            std::cout << std::right << "*";
                            }
                            
                            // Set the item's name and count //
                            std::cout << std::endl;
                            fileInput >> itemName;
                            fileInput >> itemCount;
                    }

                    // Close and set color back to default //
                    fileInput.close();
                    std::cout << defaultColor << endl;
                    break;

                // Case 4: quit the program //
                case 4:
                    return;

                // default case: for invalid input //
                default:
                    std::cout << "Selection invalid. Try again: ";
                    std::cout << std::endl;
                    break;
            }
    }
}

// Calls the DrawMenu to gather input from the user //
void main() {
    // Draws the user's menu //
    drawMenu();
}